#!/bin/sh

//CSC 365
//Lab 1-a test suite

//TC-1
//Tests Requirements R3, R4
//expected output: LIBRANDI,TODD,2,108,HAMER,GAVIN

S: LIMBRANDI

python3 studentsearch.py